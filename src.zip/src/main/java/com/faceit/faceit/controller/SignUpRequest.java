package com.faceit.faceit.controller;

import lombok.Data;

@Data
public class SignUpRequest {
    private String username;
    private String password;
}
