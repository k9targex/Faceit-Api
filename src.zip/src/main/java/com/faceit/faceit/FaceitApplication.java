package com.faceit.faceit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication

public class FaceitApplication {

	public static void main(String[] args) {

		SpringApplication.run(FaceitApplication.class, args);
	}

}

